CSparse/Source directory: primary ANSI C source code files for CSparse.
All of these files are printed verbatim in the book.  To compile the
libcsparse.a C-callable library, just type "make" in this directory.
